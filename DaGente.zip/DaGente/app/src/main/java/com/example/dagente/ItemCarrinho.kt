package com.example.dagente.model

data class ItemCarrinho(
    val produto: Produto,
    var quantidade: Int = 1
)