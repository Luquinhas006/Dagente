import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.dagente.model.ItemCarrinho
import com.example.dagente.model.Produto

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaCarrinho(
    itens: List<ItemCarrinho>,
    onVoltar: () -> Unit
) {
    val totalCarrinho = itens.sumOf { it.quantidade * it.produto.preco }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Carrinho de Compras") },
                navigationIcon = {
                    IconButton(onClick = onVoltar) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues).padding(16.dp)) {
            LazyColumn {
                items(
                    itens,
                    key = { it.produto.id}
                ) { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(item.produto.titulo)
                            Text("Qtd: ${item.quantidade}")
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("R$ %.2f".format(item.produto.preco))
                            Text("Total: R$ %.2f".format(item.quantidade * item.produto.preco))
                        }
                    }
                }
            }

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            Text("Total do Carrinho: R$ %.2f".format(totalCarrinho), fontWeight = FontWeight.Bold)
        }
    }
}