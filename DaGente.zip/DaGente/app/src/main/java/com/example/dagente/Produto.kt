package com.example.dagente.model

import androidx.annotation.DrawableRes

data class Produto(
    val id: Int,
    val titulo: String,
    val descricao: String,
    val preco: Double,
    @DrawableRes val imagem: Int
)