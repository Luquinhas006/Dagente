import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.dagente.R
import com.example.dagente.model.ItemCarrinho
import com.example.dagente.model.Produto

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController, startDestination = "cadastro") {
        composable("cadastro") {
            TelaCadastro {
                navController.navigate("index")
            }
        }
        composable("index") {
            TelaIndex(
                produtos = kotlin.collections.listOf(
                    Produto(1, "Arroz", "Pacote 5kg arroz tipo 1", 24.90, R.drawable.ic_launcher_background),
                    Produto(2, "Feijão", "Feijão carioca 1kg", 9.50, R.drawable.ic_launcher_background),
                    Produto(3, "Óleo de soja", "Óleo vegetal 900ml", 7.80, R.drawable.ic_launcher_background),
                    Produto(4, "Macarrão", "Espaguete 500g", 4.20, R.drawable.ic_launcher_background),
                    Produto(5, "Café", "Café torrado e moído 500g", 16.75, R.drawable.ic_launcher_background),
                    Produto(6, "Açúcar", "Açúcar refinado 1kg", 3.60, R.drawable.ic_launcher_background),
                    Produto(7, "Sal", "Sal refinado 1kg", 2.10, R.drawable.ic_launcher_background),
                    Produto(8, "Leite", "Leite integral 1L", 4.90, R.drawable.ic_launcher_background),
                    Produto(9, "Manteiga", "Manteiga com sal 200g", 8.90, R.drawable.ic_launcher_background),
                    Produto(10, "Papel higiênico", "Pacote com 12 rolos", 18.99, R.drawable.ic_launcher_background)
                ),
                onAdicionarCarrinho = { /* implementar */ },
                onVerCarrinho = { navController.navigate("carrinho") }
            )
        }
        composable("carrinho") {
            TelaCarrinho(
                itens = listOf(), // mock por enquanto
                onVoltar = { navController.popBackStack() }
            )
        }
    }
}